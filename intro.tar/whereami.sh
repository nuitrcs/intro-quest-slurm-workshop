#!/bin/bash

echo $HOSTNAME
echo $PWD
